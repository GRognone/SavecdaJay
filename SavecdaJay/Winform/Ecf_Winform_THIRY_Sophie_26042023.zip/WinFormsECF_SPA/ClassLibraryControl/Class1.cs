﻿using System.Text.RegularExpressions;

namespace ClassLibraryControl
{
    public class Controls
    {
        public static bool VerifIdentifiantPuce(string numberOK)
        {
            return Regex.Match(numberOK, @"^[0-9]{15}$").Success;
        }
    }
}