﻿using ClassLibraryChat;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsECF_SPA.Models;

namespace WinFormsECF_SPA
{
    public partial class FormChat2 : Form
    {
        private Chat chatDeLaListe;
        private SpaContext dbContext;

        public FormChat2(ClassChat petitNouveau)
        {
            InitializeComponent();
            dbContext = new SpaContext();
            dbContext.Chats.Load();
            dbContext.Races.Load();

            textBoxPuceNumber.Text = petitNouveau.PuceNumber.ToString();
            textBoxName.Text = petitNouveau.Name;
            textBoxAge.Text = petitNouveau.Age.ToString();
           
            comboBoxRace.DataSource = dbContext.Chats.Local.ToBindingList();
            comboBoxRace.ValueMember = "Race";
        }



        private Chat? findFromId(int _puceNumber)
        {
            return dbContext.Chats.Find(_puceNumber);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            dbContext.SaveChanges();
        }

        private void textBoxPuceNumber_TextChanged(object sender, EventArgs e)
        {
            if (ClassLibraryControl.Controls.VerifIdentifiantPuce(textBoxPuceNumber.Text)) 
            {
                errorProviderPuceNumber.SetError(textBoxPuceNumber, "veuillez saisir un identifiant à 15 chiffres");
            }
            else
            {
                errorProviderPuceNumber.Clear();
            }
        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            

           
            dbContext.SaveChanges();
        }
    }
}
